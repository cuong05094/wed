<?php

namespace App\Company;

class Employee{
   
    private $id;

    private $name;

    private $salary;

    private $department;

    private $basicSalary;

    private $allowance;

    public function __construct($id , $name , $salary, $department, $basicSalary, $allowance){
        $this->id = $id;
        $this->name = $name;
        $this->salary = $salary;
        $this->department = $department;
        $this->basicSalary = $basicSalary;
        $this->allowance = $allowance;
    }

    public function getId(){
        return $this->id;
    }

    
    public function getName(){
        return $this->name;
    }


    public function getSalary(){
        return $this->salary;
    }


    public function getDepartment(){
        return $this->department;
    }

    public function getBasicSalary(){
        return $this->basicSalary;
    }

    public function getAllowance(){
        return $this->allowance;
    }

    public function getInfo(){
        echo "Mã nhân viên $this->id <br>";
        echo "Tên nhân viên $this->name <br>";
        echo "Lương nhân viên  $this->salary <br>";
        echo "Phòng ban $this->department <br>";
        echo "Lương cơ bản $this->basicSalary <br>";
        echo "Phụ cấp $this->allowance <br>";
    }

    public function calculateSalary() {
        return $this->basicSalary + $this->allowance;
    }
}

$employee1 = new Employee("Pc09148","Cường",5000000,"Công nghệ thông tin",4000000,1000000);
