<?php
class Employee{
    public $name;

    public $age;

    public $salary;

    public $department;

    public function __construct($name, $age, $salary, $department){
        $this->name = $name;
        $this->age = $age;
        $this->salary = $salary;
        $this->department = $department;
    }

    public function setName($name){
        $this->name = $name;
    }

    public function setAge($age){
        $this->age = $age;
    }

    public function setSalary($salary){
        $this->salary = $salary;
    }

    public function setDepartment($department){
        $this->department = $department;
    }

    public function getName(){
        return $this->name;
    }

    public function getSalary(){
       return $this->salary;
    }

    public function getDepartment(){
        return $this->department;
    }

    public function getage(){
        return $this->age;
    }

    public function displayInfo(){
        echo "Tên $this->name <br>";
        echo "Tuổi $this->age <br>";
        echo "Mức lương $this->salary <br>";
        echo "Phòng ban $this->department <br>";
    }
}

$employee1 = new Employee("Cường",18,5000000,"Công nghệ thông tin");
echo $employee1->displayInfo();

$employee2 = new Employee("Cường",18,5000000,"Công nghệ thông tin");

$employee2->setName("Huy");
$employee2->setAge("19");
$employee2->setSalary("1000000");
$employee2->setDepartment("IT");

echo $employee2->displayInfo();





