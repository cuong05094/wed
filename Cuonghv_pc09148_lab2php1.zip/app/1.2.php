<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
class Order{
    public $id;

    public $date;

    public $name;

    public $product = [];

    public function __construct($id,$date,$name){
        $this->id = $id;
        $this->date = $date;
        $this->name = $name;

    }

    public function addProduct($product=[],$price=[]){
        $this->product[] = array("product"=>$product,"price"=>$price);
    }

    public function getTotalPrice(){
        $i = 0;
        foreach($this->product as $product){
            $i += $product["price"];
        }
        return $i;
    }

    public function getOrderInfo(){
        echo "$this->id <br>";
        echo "$this->date <br>";
        echo "$this->name <br>";
        foreach ($this->product as $product) {
            echo $product['product']."<br>";
          }
    }

}

$order = new Order(1,"20-20-2024","Cường");
$order->addProduct("táo",90);
$order->addProduct("Nho",100);
echo $order->getOrderInfo();
